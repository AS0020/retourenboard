import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { lstatSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { selectRuntime } from './runtime-layout.mjs';

const projectDir = fileURLToPath(new URL('../', import.meta.url));
const packageEntries = ['package.json', 'README.md', '.env.example', 'Dockerfile', 'server', 'shared', 'public', 'scripts', 'deploy', 'tests'];

function checkPackageEntry(sourceDir, entry) {
  const info = lstatSync(join(sourceDir, entry));
  if (info.isSymbolicLink()) throw new Error(`Symbolic links cannot be included in an installation package: ${entry}`);
  if (/(^|[\\/])(\.env|data|\.qa|node_modules)([\\/]|$)|\.(sqlite|sqlite-shm|sqlite-wal)$/.test(entry)) {
    throw new Error(`Private runtime data cannot be packaged: ${entry}`);
  }
  if (info.isDirectory()) {
    for (const name of readdirSync(join(sourceDir, entry))) checkPackageEntry(sourceDir, join(entry, name));
  }
}

function programArchive(sourceDir){
  const entries=[...packageEntries];
  for(const entry of entries)checkPackageEntry(sourceDir,entry);
  if(readdirSync(sourceDir).includes('dist')){checkPackageEntry(sourceDir,'dist');entries.push('dist');}
  const {version}=selectRuntime(sourceDir);
  const temporaryDir=mkdtempSync(join(tmpdir(),'retourenboard-build-'));
  try{const path=join(temporaryDir,'package.tar.gz');execFileSync('tar',['-czf',path,'-C',sourceDir,'--',...entries],{stdio:'pipe'});return {archive:readFileSync(path),version};}
  finally{rmSync(temporaryDir,{recursive:true,force:true});}
}

function installerText(sourceDir,archive){
  const checksum=createHash('sha256').update(archive).digest('hex');
  const header=readFileSync(join(sourceDir,'deploy/installer-header.sh'),'utf8').replace(/\r\n/g,'\n');
  if(!header.includes('@@PAYLOAD_SHA256@@'))throw new Error('The installer header has no checksum placeholder.');
  return `${header.replace('@@PAYLOAD_SHA256@@',checksum).trimEnd()}\n__RETOURENBOARD_PAYLOAD_BELOW__\n${archive.toString('base64').match(/.{1,76}/g).join('\n')}\n`;
}

export function buildLinuxInstaller({ sourceDir = projectDir, outputPath = join(projectDir, 'releases/latest/retourenboard-install.sh') } = {}) {
  sourceDir = resolve(sourceDir); outputPath = resolve(outputPath);
  const {archive}=programArchive(sourceDir);mkdirSync(dirname(outputPath),{recursive:true});
  writeFileSync(outputPath,installerText(sourceDir,archive),{mode:0o700});return outputPath;
}

export function buildLinuxPackages({sourceDir=projectDir,outputDir=join(projectDir,'releases')}={}){
  sourceDir=resolve(sourceDir);outputDir=resolve(outputDir);const {archive,version}=programArchive(sourceDir);
  mkdirSync(outputDir,{recursive:true});const installer=Buffer.from(installerText(sourceDir,archive));
  const files=[{folder:version,name:`retourenboard-install-${version}.sh`,data:installer},{folder:version,name:`retourenboard-linux-${version}.tar.gz`,data:archive},{folder:'latest',name:'retourenboard-install.sh',data:installer},{folder:'latest',name:'retourenboard-linux.tar.gz',data:archive}];
  const manifest={version,files:[]};
  for(const {folder,name,data}of files){
    const path=`${folder}/${name}`,target=join(outputDir,path),sha256=createHash('sha256').update(data).digest('hex');
    mkdirSync(dirname(target),{recursive:true});
    writeFileSync(target,data,{mode:name.endsWith('.sh')?0o700:0o600});
    writeFileSync(target+'.sha256',`${sha256}  ${name}\n`);
    manifest.files.push({name,path,sha256});
  }
  writeFileSync(join(outputDir,'release-manifest.json'),JSON.stringify(manifest,null,2)+'\n');return manifest;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (process.argv.length > 3) throw new Error('Usage: node scripts/build-linux-installer.mjs [output-file]');
  if(process.argv[2])console.log(`Installationsdatei erstellt: ${buildLinuxInstaller({outputPath:process.argv[2]})}`);
  else{const manifest=buildLinuxPackages();console.log(`Linuxpakete ${manifest.version} erstellt: ${manifest.files.map(file=>'releases/'+file.path).join(', ')}. Prüfsummen und releases/release-manifest.json aktualisiert.`);}
}

#!/usr/bin/env bash
# Shared by the project installer and embedded into both standalone installers.

parse_installer_args() {
  installer_action=install
  installer_purge=false
  installer_lan=false
  installer_domain=''
  while (($#)); do
    case "$1" in
      --help|-h) usage; exit 0 ;;
      --update|--uninstall)
        local requested="${1#--}"
        if [[ $installer_action != install && $installer_action != "$requested" ]]; then
          echo '--update und --uninstall können nicht gemeinsam verwendet werden.' >&2; return 1
        fi
        installer_action="$requested"; shift ;;
      --purge) installer_purge=true; shift ;;
      --lan) installer_lan=true; shift ;;
      --domain)
        [[ $# -ge 2 ]] || { echo 'Domain fehlt.' >&2; return 1; }
        installer_domain="$2"
        if [[ ! "$installer_domain" =~ ^[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?$ || "$installer_domain" != *.* || "$installer_domain" == *..* ]]; then
          echo 'Bitte einen vollständigen Domainnamen ohne https://, Port oder Pfad angeben.' >&2; return 1
        fi
        shift 2 ;;
      *) echo "Unbekannte Option: $1" >&2; return 1 ;;
    esac
  done
  if [[ $installer_lan == true && -n $installer_domain ]]; then
    echo '--lan und --domain können nicht gemeinsam verwendet werden.' >&2; return 1
  fi
  if [[ $installer_purge == true && $installer_action != uninstall ]]; then
    echo '--purge ist nur gemeinsam mit --uninstall erlaubt.' >&2; return 1
  fi
  if [[ $installer_action == uninstall && ( $installer_lan == true || -n $installer_domain ) ]]; then
    echo 'Bei --uninstall sind --lan und --domain nicht erlaubt.' >&2; return 1
  fi
  return 0
}

require_existing_installation() {
  local prefix="${1:-}"
  if [[ ! -f "$prefix/opt/retourenverwaltung/current/package.json" || ! -f "$prefix/etc/retourenverwaltung.env" ]]; then
    echo 'Keine vollständige Installation gefunden. Für eine Installation oder Reparatur das Skript ohne --update ausführen.' >&2
    return 1
  fi
}

uninstall_retourenboard() {
  # Standalone entry points always use the fixed system paths. The internal
  # prefix parameter lets tests exercise real file operations in a fixture.
  local prefix="${1:-}" purge="${2:-false}" service=retourenverwaltung.service
  local app_dir="$prefix/opt/retourenverwaltung" data_dir="$prefix/var/lib/retourenverwaltung"
  local config="$prefix/etc/retourenverwaltung.env" unit="$prefix/etc/systemd/system/$service"
  local target confirmation load_state
  [[ $purge == false || $purge == true ]] || return 1
  for target in "$app_dir" "$unit" "$config"; do
    if [[ "$(readlink -m -- "$target")" != "$target" ]]; then
      echo "Deinstallation abgebrochen: unerwartete Pfadumleitung bei $target." >&2; return 1
    fi
  done
  if [[ $purge == true ]]; then
    if [[ "$(readlink -m -- "$data_dir")" != "$data_dir" ]]; then
      echo "Deinstallation abgebrochen: unerwartete Pfadumleitung bei $data_dir." >&2; return 1
    fi
    printf 'Dabei werden Konten, Bestand und Anhänge unter %s sowie %s dauerhaft gelöscht.\n' "$data_dir" "$config"
    echo 'Separate Backups und Daten an selbst konfigurierten anderen Pfaden bleiben erhalten.'
    printf 'Zum Bestätigen LOESCHEN eingeben: '
    if ! IFS= read -r confirmation || [[ $confirmation != LOESCHEN ]]; then
      echo 'Abgebrochen. Es wurde nichts deinstalliert oder gelöscht.' >&2; return 1
    fi
  fi
  if ! load_state="$(systemctl show --property=LoadState --value "$service")"; then
    echo 'Dienststatus konnte nicht geprüft werden. Es werden keine Dateien entfernt.' >&2; return 1
  fi
  if [[ $load_state != not-found ]]; then
    systemctl stop "$service" || { echo 'Dienst konnte nicht gestoppt werden. Es werden keine Dateien entfernt.' >&2; return 1; }
    systemctl disable "$service" || { echo 'Autostart konnte nicht deaktiviert werden. Es werden keine Dateien entfernt.' >&2; return 1; }
  fi
  rm -f -- "$unit" || { echo 'Dienstdatei konnte nicht entfernt werden. Deinstallation abgebrochen.' >&2; return 1; }
  rm -rf --one-file-system -- "$app_dir" || { echo 'Programmdateien konnten nicht vollständig entfernt werden. Daten bleiben erhalten.' >&2; return 1; }
  systemctl daemon-reload || { echo 'systemd konnte nicht neu geladen werden. Daten bleiben erhalten.' >&2; return 1; }
  systemctl reset-failed "$service" >/dev/null 2>&1 || true
  if [[ $purge == true ]]; then
    rm -rf --one-file-system -- "$data_dir" || { echo 'Daten konnten nicht vollständig entfernt werden. Konfiguration bleibt erhalten.' >&2; return 1; }
    rm -f -- "$config" || { echo 'Konfiguration konnte nicht entfernt werden.' >&2; return 1; }
    echo 'retourenboard. samt Standarddaten und Konfiguration wurde deinstalliert.'
  else
    echo 'retourenboard. wurde deinstalliert. Konten, Bestand, Anhänge und Konfiguration bleiben erhalten.'
    printf 'Daten: %s\nKonfiguration: %s\n' "$data_dir" "$config"
    echo 'Eine erneute Installation verwendet diese Daten wieder.'
  fi
}

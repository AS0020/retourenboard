#!/usr/bin/env bash
set -euo pipefail

[[ -f scripts/installer-actions.sh ]] || { echo 'FAIL: shared update/uninstall actions are missing.' >&2; exit 1; }
source scripts/installer-actions.sh
usage() { echo 'fixture help'; }

parse_installer_args --update
[[ $installer_action == update && $installer_purge == false ]]
parse_installer_args --uninstall --purge
[[ $installer_action == uninstall && $installer_purge == true ]]
for args in '--purge' '--update --uninstall' '--uninstall --lan' '--uninstall --domain example.test' '--lan --domain example.test' '--domain' '--unknown'; do
  # Fixed test arguments only; no user input is interpreted here.
  if (parse_installer_args $args); then echo "FAIL: conflicting arguments accepted: $args" >&2; exit 1; fi
done

fixture_dir="$(mktemp -d)"
fixture_dir="$(cd -- "$fixture_dir" && pwd -P)"
[[ -n "$fixture_dir" && "$fixture_dir" != / && "$(readlink -m -- "$fixture_dir")" == "$fixture_dir" ]]
trap 'rm -rf -- "$fixture_dir"' EXIT
events="$fixture_dir/service-events"
fixture_load_state=loaded
stop_fails=false
reload_fails=false
systemctl() {
  printf '%s\n' "$*" >> "$events"
  if [[ $1 == show ]]; then printf '%s\n' "$fixture_load_state"; return 0; fi
  if [[ $1 == stop && $stop_fails == true ]]; then return 1; fi
  if [[ $1 == daemon-reload && $reload_fails == true ]]; then return 1; fi
  return 0
}
seed() {
  root="$fixture_dir/$1"
  mkdir -p "$root/opt/retourenverwaltung/current" "$root/var/lib/retourenverwaltung/attachments" "$root/etc/systemd/system"
  printf '{"version":"1.0.0"}\n' > "$root/opt/retourenverwaltung/current/package.json"
  printf 'database-fixture\n' > "$root/var/lib/retourenverwaltung/retouren.sqlite"
  printf 'attachment-fixture\n' > "$root/var/lib/retourenverwaltung/attachments/example.pdf"
  printf 'PORT=4321\n' > "$root/etc/retourenverwaltung.env"
  printf 'unit-fixture\n' > "$root/etc/systemd/system/retourenverwaltung.service"
  printf 'unrelated-fixture\n' > "$root/etc/another-app.env"
  : > "$events"
}

if require_existing_installation "$fixture_dir/missing"; then echo 'FAIL: update accepted without an installation.' >&2; exit 1; fi
seed 'kept data'
require_existing_installation "$root"
uninstall_retourenboard "$root" false
[[ ! -e "$root/opt/retourenverwaltung" && ! -e "$root/etc/systemd/system/retourenverwaltung.service" ]]
[[ $(cat "$root/var/lib/retourenverwaltung/retouren.sqlite") == database-fixture ]]
[[ $(cat "$root/var/lib/retourenverwaltung/attachments/example.pdf") == attachment-fixture ]]
[[ $(cat "$root/etc/retourenverwaltung.env") == PORT=4321 ]]
grep -Fxq 'stop retourenverwaltung.service' "$events"
grep -Fxq 'disable retourenverwaltung.service' "$events"
grep -Fxq 'daemon-reload' "$events"
fixture_load_state=not-found
uninstall_retourenboard "$root" false
[[ -f "$root/var/lib/retourenverwaltung/retouren.sqlite" ]]
fixture_load_state=loaded

seed cancelled
if uninstall_retourenboard "$root" true <<< 'ABBRECHEN'; then echo 'FAIL: purge succeeded without confirmation.' >&2; exit 1; fi
[[ -d "$root/opt/retourenverwaltung" && -f "$root/etc/retourenverwaltung.env" && ! -s "$events" ]]

seed purged
uninstall_retourenboard "$root" true <<< 'LOESCHEN'
[[ ! -e "$root/opt/retourenverwaltung" && ! -e "$root/var/lib/retourenverwaltung" && ! -e "$root/etc/retourenverwaltung.env" ]]
[[ $(cat "$root/etc/another-app.env") == unrelated-fixture ]]

seed 'stop failure'
stop_fails=true
if uninstall_retourenboard "$root" false; then echo 'FAIL: a running service could not be stopped, but files were removed.' >&2; exit 1; fi
[[ -f "$root/opt/retourenverwaltung/current/package.json" && -f "$root/etc/systemd/system/retourenverwaltung.service" ]]
stop_fails=false

seed 'remove failure'
if (
  rm() { return 1; }
  uninstall_retourenboard "$root" false
); then echo 'FAIL: removal errors were reported as a successful uninstall.' >&2; exit 1; fi
[[ -f "$root/opt/retourenverwaltung/current/package.json" && -f "$root/etc/systemd/system/retourenverwaltung.service" ]]

seed 'reload failure'
reload_fails=true
if uninstall_retourenboard "$root" true <<< 'LOESCHEN'; then echo 'FAIL: systemd reload failed but purge continued.' >&2; exit 1; fi
[[ -f "$root/var/lib/retourenverwaltung/retouren.sqlite" && -f "$root/etc/retourenverwaltung.env" ]]
reload_fails=false

seed symlink
app_dir="$root/opt/retourenverwaltung"
[[ "$app_dir" == "$fixture_dir/"* && "$(readlink -m -- "$app_dir")" == "$app_dir" ]]
rm -rf -- "$app_dir"
mkdir "$fixture_dir/elsewhere"
printf 'protected\n' > "$fixture_dir/elsewhere/sentinel"
case "$(uname -s)" in
  MINGW*|MSYS*)
    # Git Bash otherwise copies a directory instead of creating a real link.
    node -e "require('node:fs').symlinkSync(process.argv[1],process.argv[2],'junction')" "$(cygpath -w "$fixture_dir/elsewhere")" "$(cygpath -w "$app_dir")"
    ;;
  *) ln -s "$fixture_dir/elsewhere" "$app_dir" ;;
esac
[[ -L "$app_dir" ]]
if uninstall_retourenboard "$root" true <<< 'LOESCHEN'; then echo 'FAIL: unexpected symlink target was accepted.' >&2; exit 1; fi
[[ $(cat "$fixture_dir/elsewhere/sentinel") == protected && ! -s "$events" ]]

echo 'PASS: explicit updates, preserved data, confirmed purge, stop failures and safe paths.'

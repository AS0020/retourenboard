#!/usr/bin/env bash
set -euo pipefail
installer="${1:-retourenboard-install.sh}"
fixture_dir="$(mktemp -d)"
trap 'rm -rf -- "$fixture_dir"' EXIT
package_fixture="${2:-$fixture_dir/package.tar.gz}"
if [[ $# -lt 2 ]]; then
  tar -czf "$package_fixture" -- package.json README.md .env.example Dockerfile server shared public scripts deploy tests
fi
repository_url="$(sed -n "s/^repository_url='\(.*\)'$/\1/p" "$installer" | head -n 1)"
fixture_repository='https://github.com/AS0020/retourenboard'
stage="$(sed -n '/^# BEGIN DOWNLOAD_PACKAGE$/,/^# END DOWNLOAD_PACKAGE$/p' "$installer")"
[[ -n "$stage" ]] || { echo 'FAIL: download installation is unavailable.' >&2; exit 1; }
fixture_sha256="$(sha256sum -- "$package_fixture" | cut -d ' ' -f 1)"
printf '%s  retourenverwaltung-linux.tar.gz\n' "$fixture_sha256" > "$fixture_dir/package.sha256"
http_case=good
printf 'v2.3.4\n' > "$fixture_dir/latest-now"

# Replace only the external HTTP boundary; checksums and TAR extraction run normally.
curl() {
  local output='' url='' resolved_tag
  while (($#)); do
    case "$1" in
      --output) output="$2"; shift 2 ;;
      https://*) url="$1"; shift ;;
      *) shift ;;
    esac
  done
  [[ -n "$output" ]] || return 2
  case "$url" in
    "$fixture_repository/releases/latest")
      case "$http_case" in
        release_missing) return 22 ;;
        foreign_release) printf 'https://github.com/other/repository/releases/tag/v2.3.4'; return 0 ;;
        invalid_tag) printf '%s/releases/tag/v2.3.4/../../other' "$fixture_repository"; return 0 ;;
      esac
      # Latest changes after resolution. Both assets must still use v2.3.4.
      resolved_tag="$(cat "$fixture_dir/latest-now")"
      printf 'v9.0.0\n' > "$fixture_dir/latest-now"
      printf '%s/releases/tag/%s' "$fixture_repository" "$resolved_tag"
      ;;
    "$fixture_repository/releases/download/v2.3.4/retourenverwaltung-linux.tar.gz.sha256")
      [[ $http_case != checksum_missing ]] || return 22
      cp -- "$fixture_dir/package.sha256" "$output"
      ;;
    "$fixture_repository/releases/download/v2.3.4/retourenverwaltung-linux.tar.gz")
      [[ $http_case != package_missing ]] || return 22
      cp -- "$package_fixture" "$output"
      ;;
    *) echo "Unexpected download URL: $url" >&2; return 22 ;;
  esac
}

temp_dir="$fixture_dir/good"
mkdir "$temp_dir"
eval "$stage"
[[ $release_tag == v2.3.4 ]]
[[ -f "$temp_dir/app/server/users.js" && -f "$temp_dir/app/public/accounts.js" && -f "$temp_dir/app/scripts/install-linux.sh" ]]
[[ ! -e "$temp_dir/app/.env" && ! -e "$temp_dir/app/data" && ! -e "$temp_dir/app/.qa" ]]

# The documented Windows release command writes a digest with CRLF.
printf '%s\r\n' "${fixture_sha256^^}" > "$fixture_dir/package.sha256"
temp_dir="$fixture_dir/windows-checksum"
mkdir "$temp_dir"
printf 'v2.3.4\n' > "$fixture_dir/latest-now"
eval "$stage"
[[ -f "$temp_dir/app/server/index.js" ]]
printf '%s  retourenverwaltung-linux.tar.gz\n' "$fixture_sha256" > "$fixture_dir/package.sha256"

# If the checksum check disappears, this archive contains a file the original lacks.
cp -- "$package_fixture" "$fixture_dir/changed.tar.gz"
mkdir "$fixture_dir/extra"
printf 'modified package\n' > "$fixture_dir/extra/changed.txt"
gzip --decompress --stdout "$fixture_dir/changed.tar.gz" > "$fixture_dir/changed.tar"
tar -rf "$fixture_dir/changed.tar" -C "$fixture_dir/extra" changed.txt
gzip --stdout "$fixture_dir/changed.tar" > "$fixture_dir/damaged.tar.gz"
package_fixture="$fixture_dir/damaged.tar.gz"
temp_dir="$fixture_dir/damaged"
mkdir "$temp_dir"
printf 'v2.3.4\n' > "$fixture_dir/latest-now"
if (eval "$stage"); then
  echo 'FAIL: a damaged download must not be installed.' >&2; exit 1
fi
[[ ! -e "$temp_dir/app" ]]

# A matching checksum must not make an invalid archive installable.
http_case=good
printf 'not a gzip or tar archive\n' > "$fixture_dir/invalid.tar.gz"
package_fixture="$fixture_dir/invalid.tar.gz"
invalid_sha256="$(sha256sum -- "$package_fixture" | cut -d ' ' -f 1)"
printf '%s  retourenverwaltung-linux.tar.gz\n' "$invalid_sha256" > "$fixture_dir/package.sha256"
temp_dir="$fixture_dir/invalid-archive"
mkdir "$temp_dir"
printf 'v2.3.4\n' > "$fixture_dir/latest-now"
if (eval "$stage"); then
  echo 'FAIL: invalid archives must stop even when the checksum matches.' >&2; exit 1
fi
[[ ! -e "$temp_dir/app/scripts/install-linux.sh" ]]

for http_case in release_missing checksum_missing package_missing foreign_release invalid_tag; do
  temp_dir="$fixture_dir/$http_case"
  mkdir "$temp_dir"
  printf 'v2.3.4\n' > "$fixture_dir/latest-now"
  if (eval "$stage"); then
    echo "FAIL: $http_case must stop before installation." >&2; exit 1
  fi
  [[ ! -e "$temp_dir/app" ]]
done

http_case=good
printf 'not-a-checksum\n' > "$fixture_dir/package.sha256"
temp_dir="$fixture_dir/invalid-checksum"
mkdir "$temp_dir"
printf 'v2.3.4\n' > "$fixture_dir/latest-now"
if (eval "$stage"); then
  echo 'FAIL: malformed release checksums must not authorize installation.' >&2; exit 1
fi
[[ ! -e "$temp_dir/app" ]]

echo 'PASS: latest is resolved once; verified release assets are extracted; invalid and missing releases stop before installation.'

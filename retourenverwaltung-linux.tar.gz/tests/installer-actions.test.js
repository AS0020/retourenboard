import test from 'node:test';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const cwd=fileURLToPath(new URL('../',import.meta.url));

test('installer management preserves data, requires purge consent and stops on unsafe paths',()=>{
  const output=execFileSync('bash',['tests/install-actions.test.sh'],{cwd,encoding:'utf8',timeout:15000});
  assert.match(output,/PASS: explicit updates/);
});

test('both standalone installers explain manual updates and deinstallation',()=>{
  for(const installer of ['retourenboard-install.sh','retourenboard-offline-install.sh']){
    const output=execFileSync('bash',[installer,'--help'],{cwd,encoding:'utf8',timeout:5000});
    assert.match(output,/--update/);
    assert.match(output,/--uninstall/);
    assert.match(output,/--purge/);
  }
});

test('download installer resolves latest once and rejects unsafe or unverified release assets',()=>{
  const output=execFileSync('bash',['tests/install-download.test.sh'],{cwd,encoding:'utf8',timeout:15000});
  assert.match(output,/PASS: latest is resolved once/);
});

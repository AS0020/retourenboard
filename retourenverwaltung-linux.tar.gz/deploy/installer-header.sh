#!/usr/bin/env bash
# Generated installer with embedded program files. Rebuild with node scripts/build-linux-installer.mjs.
set -Eeuo pipefail
umask 077
payload_sha256='@@PAYLOAD_SHA256@@'

usage() {
  cat <<'HELP'
retourenboard. installieren, aktualisieren oder deinstallieren:
  bash retourenboard-offline-install.sh          (als root in der LXC-Konsole)
  sudo bash retourenboard-offline-install.sh     (mit einem normalen Linux-Konto)
  sudo bash retourenboard-offline-install.sh --update
  sudo bash retourenboard-offline-install.sh --uninstall
  sudo bash retourenboard-offline-install.sh --uninstall --purge

Eine Datei genügt. Das Programm wird automatisch entpackt, Node.js installiert
und der Dienst eingerichtet. Bei der ersten Installation ist die Anwendung
im eigenen Netzwerk über http://LXC-IP:3000 erreichbar. Die Adresse wird am
Ende angezeigt; den ersten Administrator anschließend im Browser anlegen.

Für einen vorhandenen HTTPS-Reverse-Proxy:
  sudo bash retourenboard-offline-install.sh --domain retouren.example.com
DNS, Zertifikat und Reverse Proxy werden separat eingerichtet.

Updates behalten vorhandene Konten, Daten und Servereinstellungen.
Für neue Programmversionen zuerst den neuen Offline-Installer übertragen.
--uninstall entfernt Programm, eigene Node-Laufzeit und systemd-Dienst.
Daten und Konfiguration bleiben erhalten. --purge löscht die Standarddaten
nach Eingabe von LOESCHEN. Separate Backups, Daten an anderen konfigurierten
Pfaden und der Dienstbenutzer bleiben erhalten. Deinstallation benötigt
keine Internetverbindung und entpackt das Programmpaket nicht.
Benötigt Debian/Ubuntu mit systemd; Installation: x86_64/ARM64 und Internet.
HELP
}

@@INSTALLER_ACTIONS@@

parse_installer_args "$@"
install_args=()
if [[ -n "$installer_domain" ]]; then install_args+=(--domain "$installer_domain");
else install_args+=(--lan); fi
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo 'Bitte als root oder mit sudo ausführen.' >&2; exit 1; }
[[ $(uname -s) == Linux && -f /etc/debian_version ]] || { echo 'Unterstützt werden Debian/Ubuntu mit systemd.' >&2; exit 1; }
command -v systemctl >/dev/null && [[ -d /run/systemd/system ]] || { echo 'Ein laufendes systemd ist erforderlich.' >&2; exit 1; }
if [[ $installer_action == uninstall ]]; then uninstall_retourenboard '' "$installer_purge"; exit 0; fi
if [[ $installer_action == update ]]; then require_existing_installation; fi
for program in awk tail base64 sha256sum tar gzip mktemp; do
  command -v "$program" >/dev/null || { echo "Linux-Grundprogramm fehlt: $program" >&2; exit 1; }
done

installer_file="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)/$(basename -- "${BASH_SOURCE[0]}")"
temp_dir="$(mktemp -d)"
trap 'rm -rf -- "$temp_dir"' EXIT
echo 'retourenboard. wird vorbereitet …'
# BEGIN EXTRACT_BUNDLE
payload_line="$(awk '/^__RETOURENBOARD_PAYLOAD_BELOW__$/ { print NR + 1; exit }' "$installer_file")"
[[ "$payload_line" =~ ^[0-9]+$ ]] || { echo 'Das eingebettete Programmpaket fehlt.' >&2; exit 1; }
tail -n "+$payload_line" "$installer_file" | base64 --decode > "$temp_dir/package.tar.gz"
if ! printf '%s  %s\n' "$payload_sha256" "$temp_dir/package.tar.gz" | sha256sum --check --status; then
  echo 'Die Installationsdatei ist beschädigt. Bitte erneut übertragen.' >&2; exit 1
fi
mkdir "$temp_dir/app"
tar -xzf "$temp_dir/package.tar.gz" -C "$temp_dir/app" --no-same-owner
# END EXTRACT_BUNDLE
bash "$temp_dir/app/scripts/install-linux.sh" "${install_args[@]}"
exit 0
